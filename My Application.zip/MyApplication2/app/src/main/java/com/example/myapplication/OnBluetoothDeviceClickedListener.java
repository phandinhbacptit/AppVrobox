package com.example.myapplication;

public interface OnBluetoothDeviceClickedListener {
    void onBluetoothDeviceClicked(String name, String address);
}
